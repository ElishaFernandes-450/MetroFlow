/* Tempo, beat-phase and key detection. Pure functions; runs in browser and Node. */
(function (root) {
  'use strict';

  function fft(re, im) {
    const n = re.length;
    for (let i = 1, j = 0; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) {
        let t = re[i]; re[i] = re[j]; re[j] = t;
        t = im[i]; im[i] = im[j]; im[j] = t;
      }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang), half = len >> 1;
      for (let i = 0; i < n; i += len) {
        let cr = 1, ci = 0;
        for (let k = 0; k < half; k++) {
          const a = i + k, b = a + half;
          const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
          re[b] = re[a] - tr; im[b] = im[a] - ti;
          re[a] += tr; im[a] += ti;
          const ncr = cr * wr - ci * wi;
          ci = cr * wi + ci * wr; cr = ncr;
        }
      }
    }
  }

  function hann(n) {
    const w = new Float32Array(n);
    for (let i = 0; i < n; i++) w[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (n - 1));
    return w;
  }

  /** channels: array of Float32Array, sr: sample rate. Returns mono signal reduced to ~11 kHz. */
  function prepare(channels, sr, segStartSec, segLenSec) {
    const factor = Math.max(1, Math.round(sr / 11025));
    const outSr = sr / factor;
    const start = Math.max(0, Math.floor(segStartSec * sr));
    const end = Math.min(channels[0].length, start + Math.floor(segLenSec * sr));
    const n = Math.floor((end - start) / factor);
    const out = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let s = 0;
      for (let k = 0; k < factor; k++) {
        const idx = start + i * factor + k;
        for (let c = 0; c < channels.length; c++) s += channels[c][idx];
      }
      out[i] = s / (factor * channels.length);
    }
    return { data: out, sr: outSr };
  }

  function onsetEnvelope(x, sr) {
    const N = 1024, hop = 128;
    const win = hann(N);
    const frames = Math.max(0, Math.floor((x.length - N) / hop));
    const env = new Float32Array(frames);
    const re = new Float32Array(N), im = new Float32Array(N);
    let prev = new Float32Array(N / 2);
    const bins = N / 2;
    // focus on 60 Hz – 5 kHz
    const lo = Math.floor(60 / (sr / N)), hi = Math.min(bins - 1, Math.floor(5000 / (sr / N)));
    for (let f = 0; f < frames; f++) {
      const off = f * hop;
      for (let i = 0; i < N; i++) { re[i] = x[off + i] * win[i]; im[i] = 0; }
      fft(re, im);
      let flux = 0;
      const cur = new Float32Array(bins);
      for (let b = lo; b <= hi; b++) {
        const m = Math.log(1 + 100 * Math.hypot(re[b], im[b]));
        cur[b] = m;
        const d = m - prev[b];
        if (d > 0) flux += d;
      }
      env[f] = flux;
      prev = cur;
    }
    // remove slow trend, half-wave rectify
    const out = new Float32Array(frames);
    const w = 20;
    // simple moving average subtraction
    const ma = new Float32Array(frames);
    let sum = 0, cnt = 0;
    for (let i = 0; i < frames; i++) {
      sum += env[i]; cnt++;
      if (i - 2 * w - 1 >= 0) { sum -= env[i - 2 * w - 1]; cnt--; }
      const centre = i - w;
      if (centre >= 0) ma[centre] = sum / cnt;
    }
    for (let i = frames - w; i < frames; i++) if (i >= 0) ma[i] = ma[Math.max(0, frames - w - 1)];
    let max = 1e-9;
    for (let i = 0; i < frames; i++) { out[i] = Math.max(0, env[i] - ma[i]); if (out[i] > max) max = out[i]; }
    for (let i = 0; i < frames; i++) out[i] /= max;
    return { env: out, fps: sr / hop };
  }

  function interp(env, pos) {
    const i = Math.floor(pos);
    if (i < 0 || i + 1 >= env.length) return 0;
    const f = pos - i;
    return env[i] * (1 - f) + env[i + 1] * f;
  }

  function estimateTempo(env, fps) {
    const n = env.length;
    // coarse: autocorrelation over lags for 60..200 BPM
    const minLag = Math.floor(fps * 60 / 200), maxLag = Math.ceil(fps * 60 / 60);
    const ac = new Float32Array(maxLag + 2);
    for (let lag = minLag; lag <= maxLag + 1; lag++) {
      let s = 0;
      for (let i = 0; i + lag < n; i++) s += env[i] * env[i + lag];
      ac[lag] = s / (n - lag);
    }
    let bestBpm = 120, bestScore = -1;
    for (let lag = minLag; lag <= maxLag; lag++) {
      // reinforce with multiples of the lag (beat, bar-ish) to prefer true pulse
      let s = ac[lag] + 0.5 * (ac[lag * 2] || 0) + 0.25 * (ac[lag * 4] || 0);
      const bpm = 60 * fps / lag;
      const prior = Math.exp(-0.5 * Math.pow(Math.log2(bpm / 115) / 0.9, 2));
      s *= prior;
      if (s > bestScore) { bestScore = s; bestBpm = bpm; }
    }
    // fine: comb search around the coarse estimate; also finds the phase
    let best = { bpm: bestBpm, phase: 0, score: -1 };
    for (let bpm = bestBpm - 3; bpm <= bestBpm + 3; bpm += 0.05) {
      const period = fps * 60 / bpm;
      const phaseSteps = Math.max(1, Math.round(period));
      for (let ph = 0; ph < phaseSteps; ph++) {
        const phase = ph * period / phaseSteps;
        let s = 0, k = 0;
        for (let pos = phase; pos < n - 1; pos += period, k++) {
          s += Math.max(interp(env, pos), interp(env, pos - 1), interp(env, pos + 1) * 0.9);
        }
        s /= Math.max(1, k);
        if (s > best.score) best = { bpm, phase, score: s };
      }
    }
    return best;
  }

  const MAJOR = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
  const MINOR = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  const NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

  function corr(a, b) {
    let ma = 0, mb = 0;
    for (let i = 0; i < 12; i++) { ma += a[i]; mb += b[i]; }
    ma /= 12; mb /= 12;
    let num = 0, da = 0, db = 0;
    for (let i = 0; i < 12; i++) {
      num += (a[i] - ma) * (b[i] - mb);
      da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2;
    }
    return num / Math.sqrt(da * db + 1e-12);
  }

  function estimateKey(x, sr) {
    const N = 4096, hop = 2048;
    const win = hann(N);
    const re = new Float32Array(N), im = new Float32Array(N);
    const chroma = new Float64Array(12);
    const binHz = sr / N;
    const lo = Math.ceil(65 / binHz), hi = Math.min(N / 2 - 1, Math.floor(2000 / binHz));
    const map = new Int8Array(hi + 1).fill(-1);
    for (let b = lo; b <= hi; b++) {
      const midi = 69 + 12 * Math.log2(b * binHz / 440);
      map[b] = ((Math.round(midi) % 12) + 12) % 12;
    }
    for (let off = 0; off + N <= x.length; off += hop) {
      for (let i = 0; i < N; i++) { re[i] = x[off + i] * win[i]; im[i] = 0; }
      fft(re, im);
      const frame = new Float64Array(12);
      for (let b = lo; b <= hi; b++) {
        if (map[b] < 0) continue;
        frame[map[b]] += Math.sqrt(re[b] * re[b] + im[b] * im[b]);
      }
      let tot = 0;
      for (let i = 0; i < 12; i++) tot += frame[i];
      if (tot > 0) for (let i = 0; i < 12; i++) chroma[i] += frame[i] / tot;
    }
    let best = { tonic: 0, mode: 'major', score: -2 }, second = -2;
    for (let t = 0; t < 12; t++) {
      const rot = (prof) => { const r = new Array(12); for (let i = 0; i < 12; i++) r[i] = prof[(i - t + 12) % 12]; return r; };
      for (const [mode, prof] of [['major', MAJOR], ['minor', MINOR]]) {
        const s = corr(Array.from(chroma), rot(prof));
        if (s > best.score) { second = best.score; best = { tonic: t, mode, score: s }; }
        else if (s > second) second = s;
      }
    }
    return { tonic: best.tonic, mode: best.mode, name: NAMES[best.tonic] + ' ' + best.mode, confidence: Math.max(0, Math.min(1, (best.score - second) * 4 + 0.3)) };
  }

  /** channels: Float32Array[]; returns { bpm, firstBeat (sec), key } */
  function analyse(channels, sr) {
    const dur = channels[0].length / sr;
    const segLen = Math.min(dur, 100);
    const segStart = Math.max(0, dur / 2 - segLen / 2);
    const { data, sr: lsr } = prepare(channels, sr, segStart, segLen);
    const { env, fps } = onsetEnvelope(data, lsr);
    const t = estimateTempo(env, fps);
    const period = 60 / t.bpm;
    let first = (segStart + t.phase / fps) % period;
    if (first < 0) first += period;
    // the flux frame is stamped at its window start; the attack sits about 0.75 windows later
    first = (first + 0.75 * 1024 / lsr) % period;
    const key = estimateKey(data, lsr);
    return { bpm: Math.round(t.bpm * 100) / 100, firstBeat: first, key, noteNames: NAMES };
  }

  const api = { analyse, estimateKey, estimateTempo, onsetEnvelope, prepare, NAMES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Analysis = api;
})(typeof window !== 'undefined' ? window : globalThis);
