# metroFlow

Practice player: click with subdivisions, auto tempo and key detection, key and speed change, band mixer.

Build the Android APK: open the Actions tab, run "Build Android APK", download `metroFlow-debug-apk` when it finishes.
The build copies the web files into a `www` folder, then packages them with Capacitor.
