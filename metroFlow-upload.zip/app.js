/* metroFlow: player + click + key + band mixer. Uses Tone.js (GrainPlayer for independent speed and pitch). */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const PREVIEW = !!window.__PREVIEW__;
  const mod = (a, n) => ((a % n) + n) % n;
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const ctxTime = () => Tone.getContext().currentTime;

  const S = {
    mode: 'file',            // 'file' | 'embed'
    buffer: null, dur: 0, peaks: null, player: null, playing: false, freeRun: false,
    startCtx: 0, startOff: 0, rate: 1, semis: 0, cents: 0,
    bpm: 100, firstBeat: 0, barOffset: 0, bpb: 4, subdiv: 1,
    metroOn: true, metroVol: 0.7, nextIdx: 0,
    key: null, loopA: null, loopB: null, taps: [],
  };
  let G = null; // audio graph

  /* ---------- audio graph ---------- */
  function buildGraph() {
    if (G) return G;
    const g = {};
    g.master = new Tone.Gain(1).toDestination();
    g.bus = new Tone.Gain(1);
    g.in = new Tone.Gain(1);

    // 3 frequency bands -> bus
    g.band = [0, 1, 2].map(() => new Tone.Gain(1));
    const lp = new Tone.Filter({ type: 'lowpass', frequency: 200, rolloff: -24 });
    const mhp = new Tone.Filter({ type: 'highpass', frequency: 200, rolloff: -24 });
    const mlp = new Tone.Filter({ type: 'lowpass', frequency: 2500, rolloff: -24 });
    const hp = new Tone.Filter({ type: 'highpass', frequency: 2500, rolloff: -24 });
    g.in.connect(lp); lp.connect(g.band[0]);
    g.in.connect(mhp); mhp.connect(mlp); mlp.connect(g.band[1]);
    g.in.connect(hp); hp.connect(g.band[2]);
    g.band.forEach((b) => b.connect(g.bus));

    // mid/side matrix: mid = (L+R)/2, side = (L-R)/2, out L = mid+side, out R = mid-side
    const split = new Tone.Split(2), merge = new Tone.Merge();
    const mid = new Tone.Gain(0.5), side = new Tone.Gain(0.5), negIn = new Tone.Gain(-1);
    const outL = new Tone.Gain(1), outR = new Tone.Gain(1), neg = new Tone.Gain(-1);
    g.mid = new Tone.Gain(1); g.side = new Tone.Gain(1);
    g.bus.connect(split);
    split.connect(mid, 0, 0); split.connect(mid, 1, 0);
    split.connect(side, 0, 0); split.connect(negIn, 1, 0); negIn.connect(side);
    mid.connect(g.mid); side.connect(g.side);
    g.mid.connect(outL); g.side.connect(outL);
    g.mid.connect(outR); g.side.connect(neg); neg.connect(outR);
    outL.connect(merge, 0, 0); outR.connect(merge, 0, 1);
    merge.connect(g.master);

    // click, kept out of the mixer
    g.clickGain = new Tone.Gain(S.metroVol).toDestination();
    g.click = new Tone.PolySynth(Tone.Synth, {
      oscillator: { type: 'sine' },
      envelope: { attack: 0.001, decay: 0.04, sustain: 0, release: 0.01 },
    }).connect(g.clickGain);
    g.click.maxPolyphony = 6;
    G = g;
    return g;
  }

  function newPlayer() {
    if (S.player) { try { S.player.dispose(); } catch (e) { /* already gone */ } }
    S.player = new Tone.GrainPlayer({
      url: new Tone.ToneAudioBuffer(S.buffer), grainSize: 0.15, overlap: 0.08, loop: false,
      playbackRate: S.rate, detune: S.semis * 100 + S.cents,
    }).connect(G.in);
    return S.player;
  }

  /* ---------- transport ---------- */
  function pos() {
    if (S.playing || S.freeRun) {
      let p = S.startOff + (ctxTime() - S.startCtx) * S.rate;
      if (S.mode === 'file') p = Math.min(p, S.dur);
      return Math.max(p, S.startOff);
    }
    return S.startOff;
  }

  function startAt(offset) {
    const t = ctxTime() + 0.06;
    newPlayer().start(t, offset);
    S.startOff = offset; S.startCtx = t; S.playing = true;
    resyncClick(); refreshButtons();
  }

  async function play() {
    await Tone.start();
    if (!S.buffer || S.playing) return;
    if (S.startOff >= S.dur - 0.05) S.startOff = 0;
    startAt(S.startOff);
    try { navigator.wakeLock && navigator.wakeLock.request('screen').catch(() => {}); } catch (e) { /* optional */ }
  }
  function pause() {
    if (!S.playing) return;
    const p = pos();
    try { S.player.stop(); } catch (e) { /* already stopped */ }
    S.playing = false; S.startOff = p; refreshButtons();
  }
  function seek(t) {
    if (!S.buffer) return;
    t = clamp(t, 0, S.dur);
    if (S.playing) startAt(t); else { S.startOff = t; resyncClick(); }
  }
  function reanchor() { if (S.playing || S.freeRun) { S.startOff = pos(); S.startCtx = ctxTime(); } }

  /* ---------- click ---------- */
  const subStep = () => 60 / S.bpm / S.subdiv;
  function resyncClick() { S.nextIdx = Math.ceil((S.startOff - S.firstBeat) / subStep() - 1e-6); }

  function fire(idx, t) {
    const isBeat = mod(idx, S.subdiv) === 0;
    let freq, vel;
    if (isBeat) {
      const inBar = mod(Math.floor(idx / S.subdiv) - S.barOffset, S.bpb);
      freq = inBar === 0 ? 1760 : 1175; vel = inBar === 0 ? 1 : 0.8;
    } else { freq = 880; vel = 0.4; }
    G.click.triggerAttackRelease(freq, 0.03, t, vel);
  }
  function schedule() {
    if (!G || !(S.playing || S.freeRun) || !S.metroOn) return;
    const now = ctxTime(), horizon = now + 0.18, step = subStep();
    for (let guard = 0; guard < 64; guard++) {
      const t = S.startCtx + (S.firstBeat + S.nextIdx * step - S.startOff) / S.rate;
      if (t > horizon) break;
      if (t >= now - 0.01) fire(S.nextIdx, t);
      S.nextIdx++;
    }
  }
  setInterval(schedule, 25);

  /** Change tempo but keep the beat under the playhead where it is, so the grid stays locked locally. */
  function setBpm(nb) {
    nb = clamp(nb, 30, 300);
    const per = 60 / S.bpm, np = 60 / nb;
    const k = Math.round((pos() - S.firstBeat) / per);
    const b0 = S.firstBeat + k * per;
    S.firstBeat = b0 - k * np;
    S.bpm = nb;
    resyncClick(); updateBpmUi(); drawWave();
  }
  function updateBpmUi() {
    $('bpmOut').textContent = S.bpm.toFixed(S.bpm % 1 ? 1 : 0);
    $('bpmIn').value = S.bpm.toFixed(2);
    $('freeBpm').value = S.bpm.toFixed(1);
    buildBeatDots();
  }
  function buildBeatDots() {
    const box = $('beats'); box.textContent = '';
    for (let i = 0; i < S.bpb; i++) { const d = document.createElement('i'); if (i === 0) d.className = 'first'; box.appendChild(d); }
  }

  /* ---------- key ---------- */
  function updateKeyUi() {
    const names = Analysis.NAMES;
    $('semiOut').textContent = (S.semis > 0 ? '+' : '') + S.semis;
    $('speedOut').textContent = Math.round(S.rate * 100) + '%';
    $('tuneOut').textContent = (440 * Math.pow(2, S.cents / 1200)).toFixed(1) + ' Hz';
    if (S.key) {
      $('keyOrig').textContent = S.key.name;
      $('keyNow').textContent = names[mod(S.key.tonic + S.semis, 12)] + ' ' + S.key.mode;
    } else { $('keyOrig').textContent = '—'; $('keyNow').textContent = S.semis ? (S.semis > 0 ? '+' : '') + S.semis + ' st' : '—'; }
  }
  function applyPitch() {
    if (S.player) S.player.detune = S.semis * 100 + S.cents;
    updateKeyUi();
  }

  /* ---------- waveform ---------- */
  const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  function drawWave() {
    const cv = $('waveCanvas'), box = $('wave');
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, box.clientWidth), h = box.clientHeight;
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    if (!S.peaks) return;
    const per = 60 / S.bpm, pxPerBeat = (per / S.dur) * w;
    let i0 = Math.ceil((0 - S.firstBeat) / per);
    for (let i = i0; S.firstBeat + i * per < S.dur; i++) {
      const x = Math.round((S.firstBeat + i * per) / S.dur * w) + 0.5;
      const bar = mod(i - S.barOffset, S.bpb) === 0;
      if (!bar && pxPerBeat < 4) continue;
      c.strokeStyle = bar ? cssVar('--wave-bar') : cssVar('--wave-beat');
      c.lineWidth = bar ? 1.5 : 1; c.globalAlpha = bar ? 0.9 : 0.8;
      c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke();
    }
    c.globalAlpha = 1; c.fillStyle = cssVar('--wave');
    const n = S.peaks.length, mid = h / 2;
    for (let x = 0; x < w; x++) {
      const p = S.peaks[Math.min(n - 1, Math.floor(x / w * n))];
      const bh = Math.max(1, p * (h * 0.46));
      c.fillRect(x, mid - bh, 1, bh * 2);
    }
  }
  function computePeaks(buf) {
    const cols = 1200, a = buf.getChannelData(0), b = buf.getChannelData(1), step = Math.floor(a.length / cols) || 1;
    const out = new Float32Array(cols); let max = 1e-6;
    for (let i = 0; i < cols; i++) {
      let m = 0; const s = i * step, e = Math.min(a.length, s + step);
      for (let k = s; k < e; k += 8) { const v = Math.max(Math.abs(a[k]), Math.abs(b[k])); if (v > m) m = v; }
      out[i] = m; if (m > max) max = m;
    }
    for (let i = 0; i < cols; i++) out[i] /= max;
    return out;
  }

  /* ---------- UI loop ---------- */
  const fmt = (t) => { t = Math.max(0, t); const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); };
  let lastDot = -1;
  function frame() {
    const p = (S.buffer || S.freeRun) ? pos() : 0;
    if (S.buffer) {
      $('playhead').style.left = (p / S.dur * 100) + '%';
      $('tNow').textContent = fmt(p);
      if (S.playing) {
        if (S.loopA != null && S.loopB != null && p >= S.loopB) seek(S.loopA);
        else if (p >= S.dur - 0.03) { pause(); S.startOff = S.dur; }
      }
    }
    const per = 60 / S.bpm, bi = Math.floor((p - S.firstBeat) / per) - S.barOffset;
    const since = (p - S.firstBeat) - Math.floor((p - S.firstBeat) / per) * per;
    const inBar = mod(bi, S.bpb);
    if (S.playing || S.freeRun || S.buffer) {
      $('beatPos').textContent = bi < 0 ? 'Count-in' : 'Bar ' + (Math.floor(bi / S.bpb) + 1) + ' · Beat ' + (inBar + 1);
    }
    const lit = (S.playing || S.freeRun) && S.metroOn && since < 0.09 * S.rate + 0.03 ? inBar : -1;
    if (lit !== lastDot) {
      lastDot = lit;
      [...$('beats').children].forEach((d, i) => d.classList.toggle('lit', i === lit));
    }
    requestAnimationFrame(frame);
  }

  function refreshButtons() {
    $('icoPlay').hidden = S.playing; $('icoPause').hidden = !S.playing;
    $('play').setAttribute('aria-label', S.playing ? 'Pause' : 'Play');
  }
  function setStatus(msg, err) { const s = $('status'); s.textContent = msg; s.classList.toggle('err', !!err); }

  /* ---------- loading ---------- */
  function showMode(mode) {
    S.mode = mode;
    const file = mode === 'file';
    $('transportPanel').hidden = !file && true;
    ['h-key', 'h-mix'].forEach((id) => { document.querySelector('[aria-labelledby="' + id + '"]').hidden = !file; });
    $('embedPanel').hidden = file;
  }

  async function loadArrayBuffer(ab, label) {
    stopEverything();
    showMode('file');
    setStatus('Decoding ' + label + '…');
    let decoded;
    try { decoded = await Tone.getContext().decodeAudioData(ab); }
    catch (e) { setStatus('That file could not be decoded. Try MP3, M4A, WAV, OGG or FLAC.', true); return; }
    // always work in stereo so the centre/sides controls behave
    const ctx = Tone.getContext();
    const st = ctx.createBuffer(2, decoded.length, decoded.sampleRate);
    st.getChannelData(0).set(decoded.getChannelData(0));
    st.getChannelData(1).set(decoded.getChannelData(decoded.numberOfChannels > 1 ? 1 : 0));
    S.buffer = st; S.dur = st.duration; S.peaks = computePeaks(st);
    buildGraph();
    S.startOff = 0; S.loopA = S.loopB = null; $('loopBox').hidden = true;
    $('tDur').textContent = fmt(S.dur);
    setStatus('Analysing tempo and key…');
    drawWave();
    await new Promise((r) => setTimeout(r, 30));
    try {
      const r = Analysis.analyse([st.getChannelData(0), st.getChannelData(1)], st.sampleRate);
      S.bpm = r.bpm; S.firstBeat = r.firstBeat; S.key = r.key; S.barOffset = 0;
      $('detectNote').textContent = 'Detected ' + r.bpm.toFixed(1) + ' BPM. Beat 1 is a guess: use “Beat 1 here” while the click is on the true downbeat.';
      setStatus(label + ' · ' + fmt(S.dur) + ' · ' + r.bpm.toFixed(0) + ' BPM · ' + r.key.name);
    } catch (e) {
      S.key = null; setStatus(label + ' loaded. Automatic detection failed, set the tempo by hand.', true);
    }
    updateBpmUi(); updateKeyUi(); drawWave(); resyncClick();
    $('play').disabled = false;
  }

  function stopEverything() {
    if (S.playing) pause();
    S.freeRun = false; $('freeStart').textContent = 'Start click';
    S.startOff = 0;
  }

  function parseLink(u) {
    u = u.trim(); let m;
    if ((m = u.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/)|youtu\.be\/)([\w-]{11})/i))) return { type: 'youtube', id: m[1] };
    if ((m = u.match(/open\.spotify\.com\/(?:intl-[a-z]+\/)?(track|album|playlist|episode|show)\/([A-Za-z0-9]+)/)) ||
        (m = u.match(/^spotify:(track|album|playlist|episode|show):([A-Za-z0-9]+)/))) return { type: 'spotify', kind: m[1], id: m[2] };
    if (/^https?:\/\//i.test(u)) return { type: 'audio', url: u };
    return null;
  }

  function showEmbed(info, original) {
    stopEverything();
    S.buffer = null; S.peaks = null; S.dur = 0; S.key = null; S.firstBeat = 0; S.barOffset = 0;
    showMode('embed'); buildGraph();
    const host = $('embedHost'); host.textContent = '';
    if (PREVIEW) {
      const p = document.createElement('p'); p.className = 'note';
      p.textContent = 'Embedded players are blocked in this preview. In the installed app the ' + (info.type === 'youtube' ? 'YouTube' : 'Spotify') + ' player appears here.';
      host.appendChild(p);
    } else {
      const f = document.createElement('iframe');
      if (info.type === 'youtube') {
        f.src = 'https://www.youtube-nocookie.com/embed/' + info.id + '?rel=0&playsinline=1'; f.height = '220'; f.title = 'YouTube player';
      } else {
        f.src = 'https://open.spotify.com/embed/' + info.kind + '/' + info.id; f.height = info.kind === 'track' || info.kind === 'episode' ? '152' : '352'; f.title = 'Spotify player';
      }
      f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.loading = 'lazy';
      host.appendChild(f);
    }
    const a = document.createElement('a'); a.href = original; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Open in ' + (info.type === 'youtube' ? 'YouTube' : 'Spotify');
    a.style.display = 'inline-block'; a.style.marginTop = '8px'; host.appendChild(a);
    setStatus((info.type === 'youtube' ? 'YouTube' : 'Spotify') + ' link recognised. Reference mode: playing in their player, with the click beside it.');
    $('detectNote').textContent = 'Set the tempo by hand or tap it, then press Start click when the song starts.';
    updateBpmUi(); updateKeyUi();
  }

  async function loadFromLink() {
    const raw = $('url').value;
    const info = parseLink(raw);
    if (!info) { setStatus('Paste a full link starting with https://, or a spotify: link.', true); return; }
    if (info.type !== 'audio') { showEmbed(info, raw.trim()); return; }
    setStatus('Downloading…');
    try {
      const res = await fetch(info.url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const type = res.headers.get('content-type') || '';
      if (/text\/html/i.test(type)) { setStatus('That link is a web page, not an audio file. Use a link that ends in .mp3, .m4a, .wav or similar.', true); return; }
      const ab = await res.arrayBuffer();
      const name = decodeURIComponent(info.url.split('?')[0].split('/').pop() || 'Audio');
      await loadArrayBuffer(ab, name);
    } catch (e) {
      setStatus('Could not download that link. The site may not allow other apps to read it. Save the file and choose it instead.', true);
    }
  }

  /* ---------- mixer ---------- */
  const CHANNELS = [
    { name: 'Song', sub: 'overall volume', set: (v) => (G.master.gain.value = v), max: 1.5 },
    { name: 'Bass', sub: 'under 200 Hz', set: (v) => (G.band[0].gain.value = v) },
    { name: 'Mids', sub: '200 Hz – 2.5 kHz', set: (v) => (G.band[1].gain.value = v) },
    { name: 'Highs', sub: 'over 2.5 kHz', set: (v) => (G.band[2].gain.value = v) },
    { name: 'Centre', sub: 'lead vocal, kick', set: (v) => (G.mid.gain.value = v) },
    { name: 'Sides', sub: 'wide guitars, keys', set: (v) => (G.side.gain.value = v) },
  ];
  function buildMixer() {
    const box = $('mixer');
    CHANNELS.forEach((c) => {
      const row = document.createElement('div'); row.className = 'ch';
      const nm = document.createElement('div'); nm.className = 'name'; nm.innerHTML = '<span></span><small></small>';
      nm.firstChild.textContent = c.name; nm.lastChild.textContent = c.sub;
      const r = document.createElement('input'); r.type = 'range'; r.min = 0; r.max = c.max || 1.5; r.step = 0.01; r.value = 1;
      r.id = 'ch-' + c.name.toLowerCase(); r.setAttribute('aria-label', c.name + ' level');
      const m = document.createElement('button'); m.className = 'btn'; m.textContent = 'Mute'; m.setAttribute('aria-pressed', 'false');
      const apply = () => { if (!G) return; c.set(m.classList.contains('active') ? 0 : parseFloat(r.value)); row.classList.toggle('muted', m.classList.contains('active')); };
      r.addEventListener('input', apply);
      m.addEventListener('click', () => { m.classList.toggle('active'); m.setAttribute('aria-pressed', m.classList.contains('active')); apply(); });
      row.append(nm, r, m); box.appendChild(row);
    });
  }

  /* ---------- wiring ---------- */
  function init() {
    buildMixer(); buildBeatDots(); updateBpmUi(); updateKeyUi(); showMode('file');

    $('file').addEventListener('change', async (e) => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      $('url').value = '';
      setStatus('Reading ' + f.name + '…');
      await loadArrayBuffer(await f.arrayBuffer(), f.name);
      e.target.value = '';
    });
    $('loadUrl').addEventListener('click', loadFromLink);
    $('url').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadFromLink(); });
    $('url').addEventListener('paste', () => setTimeout(() => { if (parseLink($('url').value)) loadFromLink(); }, 50));

    $('play').addEventListener('click', () => (S.playing ? pause() : play()));
    $('back').addEventListener('click', () => seek(pos() - 5));
    $('fwd').addEventListener('click', () => seek(pos() + 5));
    document.addEventListener('keydown', (e) => {
      if (e.code === 'Space' && S.mode === 'file' && S.buffer && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); S.playing ? pause() : play(); }
    });

    const wave = $('wave'); let dragging = false;
    const seekFrom = (e) => { const r = wave.getBoundingClientRect(); seek(clamp((e.clientX - r.left) / r.width, 0, 1) * S.dur); };
    wave.addEventListener('pointerdown', (e) => { if (!S.buffer) return; dragging = true; wave.setPointerCapture(e.pointerId); seekFrom(e); });
    wave.addEventListener('pointermove', (e) => { if (dragging) seekFrom(e); });
    wave.addEventListener('pointerup', () => { dragging = false; });
    new ResizeObserver(drawWave).observe(wave);
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', drawWave);

    const showLoop = () => {
      const box = $('loopBox');
      if (S.loopA == null || S.loopB == null || !S.dur) { box.hidden = true; return; }
      box.hidden = false; box.style.left = (S.loopA / S.dur * 100) + '%'; box.style.width = ((S.loopB - S.loopA) / S.dur * 100) + '%';
    };
    $('loopA').addEventListener('click', () => { if (!S.buffer) return; S.loopA = pos(); if (S.loopB != null && S.loopB <= S.loopA) S.loopB = null; showLoop(); });
    $('loopB').addEventListener('click', () => { if (!S.buffer) return; const p = pos(); if (S.loopA == null) S.loopA = 0; if (p > S.loopA + 0.2) S.loopB = p; showLoop(); });
    $('loopClear').addEventListener('click', () => { S.loopA = S.loopB = null; showLoop(); });

    // click controls
    $('metroOn').addEventListener('change', (e) => { S.metroOn = e.target.checked; resyncClick(); });
    $('metroVol').addEventListener('input', (e) => { S.metroVol = parseFloat(e.target.value); if (G) G.clickGain.gain.value = S.metroVol; });
    $('bpb').addEventListener('change', (e) => { S.bpb = parseInt(e.target.value, 10); buildBeatDots(); drawWave(); });
    document.querySelectorAll('#subdiv button').forEach((b) => b.addEventListener('click', () => {
      S.subdiv = parseInt(b.dataset.v, 10);
      document.querySelectorAll('#subdiv button').forEach((x) => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-checked', on); });
      resyncClick();
    }));
    $('bpmIn').addEventListener('change', (e) => { const v = parseFloat(e.target.value); if (v > 0) setBpm(v); else updateBpmUi(); });
    $('freeBpm').addEventListener('change', (e) => { const v = parseFloat(e.target.value); if (v > 0) setBpm(v); else updateBpmUi(); });
    $('bpmUp').addEventListener('click', () => setBpm(S.bpm + 0.5));
    $('bpmDown').addEventListener('click', () => setBpm(S.bpm - 0.5));
    $('bpmHalf').addEventListener('click', () => setBpm(S.bpm / 2));
    $('bpmDouble').addEventListener('click', () => setBpm(S.bpm * 2));
    const nudge = (d) => { S.firstBeat += d; resyncClick(); drawWave(); };
    $('nudgeL').addEventListener('click', () => nudge(-0.01));
    $('nudgeR').addEventListener('click', () => nudge(0.01));
    $('downbeat').addEventListener('click', () => {
      const per = 60 / S.bpm; S.barOffset = Math.round((pos() - S.firstBeat) / per); drawWave();
    });

    // tap tempo (reference mode and file mode)
    $('tap').addEventListener('click', () => {
      const n = performance.now();
      if (S.taps.length && n - S.taps[S.taps.length - 1] > 2000) S.taps = [];
      S.taps.push(n); if (S.taps.length > 8) S.taps.shift();
      if (S.taps.length >= 3) { const iv = (S.taps[S.taps.length - 1] - S.taps[0]) / (S.taps.length - 1); setBpm(60000 / iv); }
    });
    $('freeStart').addEventListener('click', async () => {
      await Tone.start(); buildGraph();
      if (S.freeRun) { S.freeRun = false; $('freeStart').textContent = 'Start click'; return; }
      S.startOff = 0; S.firstBeat = 0; S.startCtx = ctxTime() + 0.1; S.rate = 1; S.freeRun = true;
      resyncClick(); $('freeStart').textContent = 'Stop click';
    });

    // speed and key
    const setSpeed = (v) => { v = clamp(v, 50, 150); $('speed').value = v; reanchor(); S.rate = v / 100; if (S.player) S.player.playbackRate = S.rate; resyncClick(); updateKeyUi(); };
    $('speed').addEventListener('input', (e) => setSpeed(parseInt(e.target.value, 10)));
    document.querySelectorAll('[data-speed]').forEach((b) => b.addEventListener('click', () => setSpeed(parseInt(b.dataset.speed, 10))));
    const setSemis = (v) => { S.semis = clamp(v, -12, 12); applyPitch(); };
    $('keyUp').addEventListener('click', () => setSemis(S.semis + 1));
    $('keyDown').addEventListener('click', () => setSemis(S.semis - 1));
    $('keyReset').addEventListener('click', () => { S.cents = 0; $('cents').value = 0; setSemis(0); });
    $('cents').addEventListener('input', (e) => { S.cents = parseInt(e.target.value, 10); applyPitch(); });

    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !window.Capacitor && !PREVIEW) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
    requestAnimationFrame(frame);
  }

  window.metroFlow = { S, play, pause, seek, loadArrayBuffer, parseLink, get graph() { return G; } };
  init();
})();
